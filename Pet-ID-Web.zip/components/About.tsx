// AboutMe.tsx
"use client"
import React, { useEffect, useRef, useState } from 'react';
import Image from 'next/image';
import styles from '@/styles/AboutUs.module.css'; // Import the CSS module

const AboutMe: React.FC = () => {
  const photoRef = useRef(null);
  const textRef = useRef(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const photoTop = photoRef.current.getBoundingClientRect().top;
      const textTop = textRef.current.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;

      if (photoTop < windowHeight && textTop < windowHeight) {
        setIsInView(true);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className={styles.container}>
      <div ref={photoRef}
          className={`${styles.imageContainer} ${isInView ? styles.slideInLeft : ''}`}>
        <Image
          src="/images/wendy.webp" // Update with the correct path to your image
          alt="Wendy"
          width={448}
          height={480}
          className={`${styles.image} ${isInView ? styles.slideInLeft : ''}`}
        />
      </div>
      <div ref={textRef}
      className={`${styles.textContainer} ${isInView ? styles.slideInLeft : ''}`}>
        <h2>Hi, I’m Wendy</h2>
        <p>
          I’m a paragraph. Click here to add your own text and edit me. It’s easy. Just click “Edit Text” or double click me to add your own content and make changes to the font. Feel free to drag and drop me anywhere you like on your page. I’m a great place for you to tell a story and let your users know a little more about you.
        </p>
        <p>
          This is a great space to write a long text about your company and your services. You can use this space to go into a little more detail about your company.
        </p>
      </div>
    </section>
  );
};

export default AboutMe;